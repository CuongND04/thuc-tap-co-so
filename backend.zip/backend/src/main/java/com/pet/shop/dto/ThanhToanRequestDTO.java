package com.pet.shop.dto;

import lombok.Data;


@Data
public class ThanhToanRequestDTO {
    private String phuongThucThanhToan;
    private String diaChiGiaoHang;
    private String soDienThoai;
    private String ghiChu;
} 