package com.pet.shop.dto;

public class ThemVaoGioDTO {
    private Long maGioHang;
    private Long maSanPham;
    private Integer soLuong;
    // getter, setter
} 