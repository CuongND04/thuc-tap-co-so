package com.pet.shop.dto;

import lombok.Data;
 
@Data
public class ThemGioHangDTO {
    private Long maKhachHang;
    private Long maSanPham;
    private Integer soLuong;
} 